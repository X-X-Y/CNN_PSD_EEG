function dat= proc_logarithm10(dat)
%PROC_LORARITHM - computes the practical logarithm
%
%Synopsis:
% dat= proc_logarithm10(dat);
%
%Arguments:
%     dat     -  continuous or epoched EEG data
% 
%Returns:
%     dat     -  updated data struct
%     
dat = misc_history(dat);

dat.x= log(dat.x)/log(10);
