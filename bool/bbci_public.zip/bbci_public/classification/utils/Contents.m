% This folder contains scripts/utilities to support the functionality of classifiers
%
%
%CLSUTIL_SHRINKAGE - Determine shrinkage parameter of a classifier. 
%                    Example: the degree of regularization of the estimated covariance matrix 
%                    towards a unit sphere (used in LDA classifiers)
