% This directory contains the C code for the mex-file version of FILE_READBV
% as well as function that loads BV data without using mex-files.
