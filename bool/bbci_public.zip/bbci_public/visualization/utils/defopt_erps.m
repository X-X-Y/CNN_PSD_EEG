function opt= defopt_erps(varargin)
%DEFOPT_ERPS - Properties for plot_channel* functions, optimized for
%plotting ERPs

props= {'LineWidth',                    2
    'AxisType',                     'cross'
    'AxisTitleVerticalAlignment',   'top'
    'AxisTitleFontWeight',          'bold'
    'ScaleHPos',                    'left'
    %         'ColorOrder',             [1 .47 .02; .3 .3 .3; 0 .6 .8; .9 0 .9]
    'ColorOrder',             [1 0 0; 0 0 1; 0 1 0; 1 1 0]
    'XGrid',                        'on'
    'YGrid',                        'on'
    'GridOverPatches',              1

    };

opt= opt_proplistToStruct(varargin{:});
opt= opt_setDefaults(opt, props);
